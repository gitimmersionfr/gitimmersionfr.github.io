# L'argument par défaut est Monde
nom = ARGV.first || "Monde"

puts "Bonjour, #{nom}!"
