puts "Quelle est votre nom?"
mon_nom = gets.strip

puts "Bonjour, #{mon_nom}!"
