class Faireunsalut
  def initialize(who)
    @who = who
  end
  def saluer
    "Bonjour, #{@who}"
  end
end
