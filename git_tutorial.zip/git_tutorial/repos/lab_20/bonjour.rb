# L'argument par défaut est Monde
# Auteur: Jim Weirich (jim@somewhere.com)
nom = ARGV.first || "Monde"

puts "Bonjour, #{nom}!"
